CustomTNT 16x cube display pack for Paper/Minecraft 26.2.
These models are cubic so ItemDisplay overlays look like real placed blocks.
