CustomTNT 16x resource pack for Minecraft/Paper 26.1.2.

This pack supports the plugin's item_model component through assets/customtnt/items/*.json.
It also includes assets/minecraft/items/tnt.json and firework_star.json numeric custom_model_data fallbacks for older CustomTNT test jars.
Use the matching CustomTNT plugin 1.0.5 or newer for best results.
